mv -f ./Slimdown_fix.php /var/www/html/include/Slimdown.php
