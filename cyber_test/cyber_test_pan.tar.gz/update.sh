mv -f ./app_fix.py /cyber/app.py
